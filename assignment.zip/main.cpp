/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;

int main() {
    double celsius, fahrenheit;

    // Ask user to input temperature in Celsius
    cout << "Enter temperature in Celsius: ";
    cin >> celsius;

    // Convert to Fahrenheit
    fahrenheit = (celsius * 1.8) + 32;

    // Output result
    cout << "Temperature in Fahrenheit: " << fahrenheit << endl;

    // Bonus conditions
    if (celsius < 0) {
        cout << "Freezing!" << endl;
    }
    else if (celsius > 30) {
        cout << "Hot!" << endl;
    }

    return 0;
}